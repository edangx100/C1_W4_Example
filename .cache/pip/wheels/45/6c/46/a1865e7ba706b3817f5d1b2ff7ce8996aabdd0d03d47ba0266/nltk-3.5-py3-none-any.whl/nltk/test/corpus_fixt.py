# -*- coding: utf-8 -*-

from nltk.corpus import teardown_module
